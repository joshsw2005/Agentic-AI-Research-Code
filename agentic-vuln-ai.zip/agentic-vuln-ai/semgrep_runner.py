import json
import subprocess
from pathlib import Path
from typing import Any, Dict, List


def run_semgrep(repo_path: str, config: str = "auto") -> Dict[str, Any]:
    cmd = [
        "semgrep",
        "scan",
        "--config",
        config,
        "--json",
        repo_path,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)

    if result.returncode not in (0, 1):
        raise RuntimeError(
            "Semgrep failed.\n"
            f"STDOUT:\n{result.stdout}\n\nSTDERR:\n{result.stderr}"
        )

    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Failed to parse Semgrep JSON output: {result.stdout[:1000]}") from exc


def _read_code_window(path: Path, start_line: int, end_line: int, padding: int = 4) -> str:
    if not path.exists():
        return ""

    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    start = max(1, start_line - padding)
    end = min(len(lines), end_line + padding)

    snippet = []
    for idx in range(start, end + 1):
        snippet.append(f"{idx}: {lines[idx - 1]}")
    return "\n".join(snippet)


def simplify_findings(semgrep_json: Dict[str, Any], repo_path: str) -> List[Dict[str, Any]]:
    findings: List[Dict[str, Any]] = []

    for result in semgrep_json.get("results", []):
        path = result.get("path", "")
        start_line = result.get("start", {}).get("line", 0)
        end_line = result.get("end", {}).get("line", start_line)
        absolute_path = Path(repo_path) / path if not Path(path).is_absolute() else Path(path)

        finding = {
            "rule_id": result.get("check_id", ""),
            "message": result.get("extra", {}).get("message", ""),
            "severity": result.get("extra", {}).get("severity", "Unknown"),
            "path": str(absolute_path),
            "start_line": start_line,
            "end_line": end_line,
            "code": _read_code_window(absolute_path, start_line, end_line),
        }
        findings.append(finding)

    return findings
