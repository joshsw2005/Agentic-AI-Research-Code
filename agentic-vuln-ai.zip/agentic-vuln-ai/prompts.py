def build_analysis_prompt(finding: dict) -> str:
    return f"""
You are a secure code reviewer helping a vulnerability-management agent.

Analyze the Semgrep finding below and decide whether it likely represents a real vulnerability.

Return JSON only with this exact schema:
{{
  "is_true_positive": true,
  "vulnerability_type": "",
  "cwe": "",
  "severity": "Low|Medium|High|Critical|Unknown",
  "explanation": "",
  "exploit_scenario": "",
  "remediation": "",
  "confidence": 0.0
}}

Rules:
- Be conservative.
- If you are uncertain, say so in the explanation and lower the confidence.
- Use the code and Semgrep metadata only.
- Do not include markdown fences.

Semgrep finding:
rule_id: {finding.get('rule_id', '')}
message: {finding.get('message', '')}
severity: {finding.get('severity', '')}
path: {finding.get('path', '')}
start_line: {finding.get('start_line', '')}
end_line: {finding.get('end_line', '')}

Code snippet:
{finding.get('code', '')}
""".strip()
