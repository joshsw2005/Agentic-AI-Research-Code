import argparse
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List

from llm_client import chat_completion
from prompts import build_analysis_prompt
from semgrep_runner import run_semgrep, simplify_findings


def load_env_file(env_path: str = ".env") -> None:
    path = Path(env_path)
    if not path.exists():
        return

    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())


def analyze_findings(findings: List[Dict], max_findings: int) -> List[Dict]:
    analyzed = []
    for idx, finding in enumerate(findings[:max_findings], start=1):
        print(f"[+] Analyzing finding {idx}/{min(len(findings), max_findings)}: {finding['rule_id']}")
        prompt = build_analysis_prompt(finding)
        llm_result = chat_completion(prompt)
        analyzed.append({
            "finding": finding,
            "llm_analysis": llm_result,
        })
    return analyzed


def build_report(repo: str, config: str, semgrep_json: Dict, analyzed_findings: List[Dict]) -> Dict:
    return {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "repo": repo,
        "semgrep_config": config,
        "summary": {
            "total_semgrep_findings": len(semgrep_json.get("results", [])),
            "analyzed_findings": len(analyzed_findings),
        },
        "results": analyzed_findings,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Semgrep and analyze findings with an LLM.")
    parser.add_argument("--repo", required=True, help="Path to the repository to scan")
    parser.add_argument("--output", default="results/latest_report.json", help="Path to output JSON report")
    parser.add_argument("--max-findings", type=int, default=3, help="Maximum number of findings to analyze")
    parser.add_argument("--semgrep-config", default=None, help="Semgrep config. Defaults to SEMGREP_CONFIG or auto")
    args = parser.parse_args()

    load_env_file()

    repo_path = Path(args.repo)
    if not repo_path.exists():
        raise FileNotFoundError(f"Repository path not found: {repo_path}")

    semgrep_config = args.semgrep_config or os.environ.get("SEMGREP_CONFIG", "auto")

    print(f"[+] Running Semgrep on: {repo_path}")
    semgrep_json = run_semgrep(str(repo_path), config=semgrep_config)

    findings = simplify_findings(semgrep_json, str(repo_path))
    print(f"[+] Semgrep found {len(findings)} result(s)")

    if not findings:
        print("[+] No findings to analyze")
        report = build_report(str(repo_path), semgrep_config, semgrep_json, [])
    else:
        analyzed = analyze_findings(findings, args.max_findings)
        report = build_report(str(repo_path), semgrep_config, semgrep_json, analyzed)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"[+] Report written to: {output_path}")


if __name__ == "__main__":
    main()
