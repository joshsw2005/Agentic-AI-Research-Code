# Agentic Vulnerability AI Starter

This is a minimal starter project for a simple agentic AI workflow:

1. Run **Semgrep** on a target repository
2. Extract findings
3. Send each finding to your LLM (**Qwen3-Code-Next** or your provider's exact model name)
4. Save a structured JSON report

## Project layout

```text
agentic-vuln-ai/
├── README.md
├── requirements.txt
├── .env.example
├── main.py
├── llm_client.py
├── prompts.py
├── semgrep_runner.py
└── results/
```

## What you need to install

### 1) Python
Use Python 3.10+.

Check it:

```bash
python3 --version
```

### 2) Semgrep
Install with pip:

```bash
pip install -r requirements.txt
```

This installs:
- `semgrep`
- `requests`

### 3) LLM access
You need an API endpoint for your Qwen model.

This starter assumes your provider exposes an **OpenAI-compatible chat completions API**.

You will set:
- `LLM_API_KEY`
- `LLM_API_URL`
- `LLM_MODEL`

Example:

```env
LLM_API_KEY=your_key_here
LLM_API_URL=https://your-provider.example/v1/chat/completions
LLM_MODEL=Qwen3-Code-Next
```

If your provider uses a different URL or payload format, update `llm_client.py`.

## Setup

### Option A: simple local setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Then edit `.env` with your real API key and endpoint.

### Option B: no virtual environment

```bash
pip install -r requirements.txt
cp .env.example .env
```

## What to scan

Put or clone a vulnerable test repository anywhere on your machine.

Example:

```bash
git clone https://github.com/OWASP/PyGoat.git repos/PyGoat
```

Then run:

```bash
python main.py --repo repos/PyGoat
```

## First run

```bash
python main.py --repo repos/PyGoat --max-findings 3
```

This will:
- run Semgrep
- analyze up to 3 findings with the LLM
- write output to `results/latest_report.json`

## Environment variables

The script reads `.env` automatically if present.

- `LLM_API_KEY`: your provider API key
- `LLM_API_URL`: chat completions endpoint
- `LLM_MODEL`: exact model name from your provider
- `SEMGREP_CONFIG`: optional, default is `auto`
- `LLM_TIMEOUT_SECONDS`: optional, default is `90`

## Example command

```bash
python main.py --repo repos/PyGoat --max-findings 5 --output results/pygoat_report.json
```

## Next improvement steps

After this basic version works, add:

1. true positive / false positive judging
2. reproduction step generation
3. patch generation
4. patch verification with re-scan
5. benchmark metrics
